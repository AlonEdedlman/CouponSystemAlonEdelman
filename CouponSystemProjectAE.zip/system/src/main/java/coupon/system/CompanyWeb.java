package coupon.system;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

import core.beans.Company;
import core.beans.Coupon;

@XmlRootElement
public class CompanyWeb implements Serializable{
	private long id;
	private String compName;
	private String password;
	private String email;

	public CompanyWeb() {

	}

	public CompanyWeb(Company company) {

		super();
		this.id=company.getId();
		this.compName = company.getCompName();
		this.password = company.getPassword();
		this.email = company.getEmail();
	}

	public Company convertToCompany() {
		Company result = new Company(this.id, this.compName, this.password, this.email);
		return result;
	}

	public static Collection<Company> convertToCompanies(Collection<CompanyWeb> companies) {
		Collection<Company> result = new ArrayList<>();
		for (CompanyWeb c : companies) {
			result.add(c.convertToCompany());
		}
		return result;
	}

	public static Collection<CompanyWeb> convertToWebCompanies(Collection<Company> companies) {
		Collection<CompanyWeb> result = new ArrayList<>();
		for (Company c : companies) {
			result.add(new CompanyWeb(c));
		}
		return result;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCompName() {
		return compName;
	}

	public void setCompName(String compName) {
		this.compName = compName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "CompanyWeb [id=" + id + ", compName=" + compName + ", password=" + password + ", email=" + email + "]";
	}
	
	

}
