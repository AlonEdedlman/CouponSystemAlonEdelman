

function Company(id, name)
{
    this.id = id
    this.name = compName
    this.password = password
    this.email = email
}