function Customer(id, name)
{
    this.id = id
    this.name = custName
    this.password = password
}