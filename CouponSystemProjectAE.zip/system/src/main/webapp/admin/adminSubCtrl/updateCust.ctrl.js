var module = angular.module("adminApp")
module.controller("UpdateCustCtrl", UpdateCustCtrlCtor)



function UpdateCustCtrlCtor(adminServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.customers = [];
    this.custUpdate = {};
    this.success = false;
    this.failure = false;
    this.showTable = false;

    var self = this;
    
        
    this.updateCustomer = function(){
        
        
        var promise = adminServiceHTTP.updateCustomer(self.custUpdate)
        promise.then(function(resp){
          console.log(resp.data);
       debug = resp;
       ErrorHandlerSrvc.checkData(resp.data);
       self.errDetails = {"error": false, "msg":""};
       self.getAllCustomers();
        },
        function(err)
        {
            
         console.log(err)
      debug = err;
      self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        }
        ) 
    }

    this.getAllCustomers = function(){
        
                var promise = adminServiceHTTP.getAllCustomers()
                promise.then(function (resp) {
                         console.log(resp.data);
                         debug = resp;
                         ErrorHandlerSrvc.checkData(resp.data);
                         self.errDetails = {"error": false, "msg":""};
                         self.customers = resp.data;
                        },
                        function (err) {
                            
                            console.log(err)
                            debug = err;
                            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                        }
                    )
                    
                } 
 this.getCustomerBeforeUpdate = function(){
    this.showTable=true;
            var promise = adminServiceHTTP.getCustomer(self.custId)
            promise.then(
                
                function (resp) {
                    console.log(resp.data);
                    debug = resp;
                    ErrorHandlerSrvc.checkData(resp.data);
                    self.errDetails = {"error": false, "msg":""};
                    self.custUpdate = resp.data;
                },
                function (err) {
                    
                    console.log(err)
                    debug = err;
                    self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                }
            )
        }


this.getAllCustomers();
}
