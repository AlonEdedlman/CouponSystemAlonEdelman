var module = angular.module("adminApp")
module.controller("DeleteCustCtrl", DeleteCustCtrlCtor)

function DeleteCustCtrlCtor(adminServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.custDelete={};
    this.customers = [];
    this.success = false;
    this.failure = false;

    var self = this;
    

    this.deleteCustomer = function(){

        if (this.custDelete.id == undefined || this.custDelete.id == null )
        {
            this.success = false;
            this.failure = true;
            return;
        }
        this.success = false;
        this.failure = false;

        var promise = adminServiceHTTP.deleteCustomer(self.custDelete.id)
        promise.then(function(resp){
        console.log(resp.data);
        debug = resp;
        ErrorHandlerSrvc.checkData(resp.data);
        self.errDetails = {"error": false, "msg":""};
        self.success = true;
        self.failure = false;
        
        },
        function(err)
        {
            console.log(err)
            debug = err;
            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);

            self.success = false;
            self.failure = true;
        }
        ) 
    }
    this.getAllCustomers = function(){
        
                var promise = adminServiceHTTP.getAllCustomers()
                promise.then(function (resp) {
                         console.log(resp.data);
                         debug = resp;
                         ErrorHandlerSrvc.checkData(resp.data);
                         self.errDetails = {"error": false, "msg":""};
                         self.customers = resp.data;
                        },
                        function (err) {
                            
                            console.log(err)
                            debug = err;
                            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                        }
                    )
                    
                } 


this.getAllCustomers();
}