var module = angular.module("adminApp")
module.controller("UpdateCompCtrl", UpdateCompCtrlCtor)



function UpdateCompCtrlCtor(adminServiceHTTP, ErrorHandlerSrvc) {

    this.companies = [];
    this.errDetails = {"error": false, "msg":""};
    this.compUpdate = {};
    this.success = false;
    this.failure = false;
    this.showTable = false;

    var self = this;
    

    this.updateCompany = function(){
        
        
        var promise = adminServiceHTTP.updateCompany(self.compUpdate)
        promise.then(function(resp){
          console.log(resp.data);
          debug = resp;
          ErrorHandlerSrvc.checkData(resp.data);
          self.errDetails = {"error": false, "msg":""};
          
          self.getAllCompanies();
        },
        function(err)
        {
            
         console.log(err)
      debug = err;
      self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        }
        ) 
    }
        
    

    this.getAllCompanies = function(){
        
                     var promise = adminServiceHTTP.getAllCompanies()
                     promise.then(
                        
                        function (resp) {
                            console.log(resp.data);
                            debug = resp;
                            ErrorHandlerSrvc.checkData(resp.data);
                            self.errDetails = {"error": false, "msg":""};
                            self.companies = resp.data;
                        },
                        function (err) {
                            
                            console.log(err)
                            debug = err;
                            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                        }
                    )
                }


this.getCompanyBeforeUpdate = function(){
    this.showTable=true;
    var promise = adminServiceHTTP.getCompany(this.compId)
    promise.then(
        
        function (resp) {
            console.log(resp.data);
            debug = resp;
            ErrorHandlerSrvc.checkData(resp.data);
            self.errDetails = {"error": false, "msg":""};
            self.compUpdate = resp.data;
        },
        function (err) {
            
            console.log(err)
            debug = err;
            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        }
    )
   
  }
this.getAllCompanies();
}
