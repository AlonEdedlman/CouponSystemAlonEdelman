var module = angular.module("adminApp")
module.controller("GetAllCustCtrl", GetAllCustCtrlCtor)

function GetAllCustCtrlCtor(adminServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.customers = [];
    var self = this;



    this.orderB = "id";
	this.goUp = false;
    
	this.setOrder = function (field) {
		this.goUp = (this.orderB != field) ? false : !this.goUp;
		this.orderB = field;
		console.log(this.orderB)
		this.getAllCustomers();

	}
    this.getAllCustomers = function(){
        
                var promise = adminServiceHTTP.getAllCustomers()
                promise.then(function (resp) {
                         console.log(resp.data);
                         debug = resp;
                         ErrorHandlerSrvc.checkData(resp.data);
                         self.errDetails = {"error": false, "msg":""};
                         self.customers = resp.data;
                        },
                        function (err) {
                            
                            console.log(err)
                            debug = err;
                            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                        }
                    )
                    
                } 
    
    

 this.getAllCustomers();
}

