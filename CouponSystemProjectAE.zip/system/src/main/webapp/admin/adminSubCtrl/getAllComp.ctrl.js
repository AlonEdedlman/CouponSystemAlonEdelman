var module = angular.module("adminApp")
module.controller("GetAllCompCtrl", GetAllCompCtrlCtor)

function GetAllCompCtrlCtor(adminServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.companies = [];
    var self = this;



    this.orderB = "id";
	this.goUp = false;
    
	this.setOrder = function (field) {
		this.goUp = (this.orderB != field) ? false : !this.goUp;
		this.orderB = field;
		console.log(this.orderB)
		this.getAllCompanies()

	}
   
    
    this.getAllCompanies = function(){
        
                     var promise = adminServiceHTTP.getAllCompanies()
                     promise.then(
                        
                        function (resp) {
                            console.log(resp.data);
                            debug = resp;
                            ErrorHandlerSrvc.checkData(resp.data);
                            self.errDetails = {"error": false, "msg":""};
                            self.companies = resp.data;
                        },
                        function (err) {
                            
                            console.log(err)
                            debug = err;
                            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                        }
                    )
                }
   

this.getAllCompanies();
}

