var module = angular.module("compApp")
module.controller("CreateImgCtrl", CreateImgCtrlCtor)



function CreateImgCtrlCtor(compServiceHTTP) {

    this.coup = {"id":"","name":"","type":"","price":"","amount":"","startDate":"","endDate":"","image":"","type":"","message":""};
    this.images = [];
    this.errDetails = {"error": false, "msg":""};
  
    
    var self = this;



    this.backToCreateCoup = function(image){
        var promise = compServiceHTTP.backToCreateCoup(image)
        
        promise.then(
            
                        function (resp) {
                            console.log(resp.data);
                            debug = resp;
                            self.errDetails = {"error": false, "msg":""};
                            window.location.href = resp.data;
                            
                        },
                        function (err) {
                            
                            console.log(err)
                            debug = err;
                            self.errDetails = {"error": true, "msg":"direct back to create coupon faild!"};
                            self.coup = {};
                            
                        }
                    )
    }
    this.getCouponWebFromSession = function(){
        var promise = compServiceHTTP.getCouponWebFromSession()
        promise.then(
            
                        function (resp) {
                            console.log(resp.data);
                            debug = resp;
            
                            self.coup = resp.data;
                            
                            
                        },
                        function (err) {
                            
                            console.log(err)
                            debug = err;
                            
                            window.location.href = "./compPage3.html#/create";
                        }
                    )
    }
 
    this.getCouponWebFromSession();
    
    for(var i = 1; i<4;i++){
        this.images[i-1]= "./images/"+this.coup.type+i+".jpg"
    } 
}