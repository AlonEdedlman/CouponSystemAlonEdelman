var module = angular.module("compApp")
module.controller("GetCouponsCtrl", GetCouponsCtrlCtor)



function GetCouponsCtrlCtor(compServiceHTTP, ErrorHandlerSrvc) {
  
    this.errDetails = {"error": false, "msg":""};
    this.compCoupons = []
    var self = this;



    this.orderB = "";
	this.goUp = false;
    
	this.setOrder = function (field) {
		this.goUp = (this.orderB != field) ? false : !this.goUp;
		this.orderB = field;
		console.log(this.orderB)
		this.getCoupons()

	}
   
    

   this.getCoupons = function(){
    var promise = compServiceHTTP.getCoupons()
     promise.then(

        function (resp) {
            console.log(resp.data);
            debug = resp;
            self.errDetails = {"error": false, "msg":""};
            self.compCoupons = resp.data;

            ErrorHandlerSrvc.checkData(resp.data);
        },
        function (err) {
        	
            console.log(err)
            debug = err;
            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        }
    )
}

this.getCoupons()
}




