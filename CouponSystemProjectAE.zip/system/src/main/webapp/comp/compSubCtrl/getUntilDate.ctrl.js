var module = angular.module("compApp")
module.controller("GetUntilDateCtrl", GetUntilDateCtrlCtor)


function GetUntilDateCtrlCtor(compServiceHTTP, ErrorHandlerSrvc) {
    this.minDate = new Date(new Date().setHours(0,0,0)-(1000*60*60));
    this.errDetails = {"error": false, "msg":""};
    this.noResultMsg = false;
    
    this.showTable = false;
    
    this.couponsUntilDate = []
    var self = this;



    this.orderB = "";
	this.goUp = false;
    
	this.setOrder = function (field) {
		this.goUp = (this.orderB != field) ? false : !this.goUp;
		this.orderB = field;
		console.log(this.orderB)
        this.getCoupUntilEndDate();
        
        

	}
   

        this.getCoupUntilEndDate = function(){
            
            self.limitDate = new Date(self.endDateTG).getTime();
       
            var promise = compServiceHTTP.getCoupUntilEndDate(self.limitDate)
            promise.then(
               
             function (resp) {
                 console.log(resp.data);
                 debug = resp;
                 self.errDetails = {"error": false, "msg":""};
                 self.couponsUntilDate = resp.data;

                 ErrorHandlerSrvc.checkData(resp.data);

                 if(resp.data==""){
                    self.noResultMsg = true;
                    self.showTable=false;
                }else{
                    self.showTable=true;
                    self.noResultMsg = false;
                }
             },
             function (err) {
                 
                 console.log(err)
                 debug = err;
                 
                 self.noResultMsg = true;
                 self.showTable = false;
                 self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
             }
       )
           }
}