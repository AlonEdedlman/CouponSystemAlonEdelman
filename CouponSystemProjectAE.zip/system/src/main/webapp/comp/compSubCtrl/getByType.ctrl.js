var module = angular.module("compApp")
module.controller("GetByTypeCtrl", GetByTypeCtrlCtor)


function GetByTypeCtrlCtor(compServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.noResultMsg = false;
    
    this.showTable = false;
    this.couponsByType = []
    var self = this;
    this.coupType = "CAMPING";



    this.orderB = "";
	this.goUp = false;
    
	this.setOrder = function (field) {
		this.goUp = (this.orderB != field) ? false : !this.goUp;
		this.orderB = field;
		console.log(this.orderB)
		this.getCoupByType()

	}
   
    this.getCoupByType = function(){
        var promise = compServiceHTTP.getCoupByType(this.coupType)
        promise.then(
        		
        		function (resp) {
        			console.log(resp.data);
                    debug = resp;
                    self.errDetails = {"error": false, "msg":""};
                    self.couponsByType = resp.data;

                    ErrorHandlerSrvc.checkData(resp.data);
                    
                    if(resp.data==""){
                        self.noResultMsg = true;
                        self.showTable=false;
                    }else{
                        self.showTable=true;
                        self.noResultMsg = false;
                    }
                    
        		},
        		function (err) {
        			
        			console.log(err)
                    debug = err;
                    self.noResultMsg = true;
                    self.showTable = false;
                    self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        		}
        )
        }
}