var module = angular.module("compApp")
module.controller("GetByLimitCtrl", GetByLimitCtrlCtor)


function GetByLimitCtrlCtor(compServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.noResultMsg = false;
    
     this.errMsg = {"error": false, "msg":""};
     this.preSubmit = true;
    
    this.showTable = false;
    
    this.couponsByPrice = [];
    var self = this;



    this.orderB = "";
	this.goUp = false;
    
	this.setOrder = function (field) {
		this.goUp = (this.orderB != field) ? false : !this.goUp;
		this.orderB = field;
		console.log(this.orderB)
		this.getCoupByLimit();

	}
   
    this.checkErr = function(){
        
                this.errMsg = ErrorHandlerSrvc.checkPrice(this.coupPriceLimit);
        
                if(this.errMsg.error){
                    if((this.errMsg.msg=="The price should be between 0 to 10000" && this.coupPriceLimit<0)){
         
                        this.coupPriceLimit = 0;
                    }
                   
                }
            }

    this.checkErrPreSubmit = function(){
        this.preSubmit = true;
        this.noResultMsg = false;
        this.checkErr();
        
    }
        this.getCoupByLimit = function(){

            this.preSubmit = false;
            this.checkErr();
            
            self.errDetails = {"error": false, "msg":""};
            if(!(this.errMsg.error)){
            this.preSubmit = true;
           
            var promise = compServiceHTTP.getCoupByLimit(this.coupPriceLimit)
            promise.then(
                      
                    function (resp) {
                        console.log(resp.data);
                        debug = resp;
                        
                        self.couponsByPrice = resp.data;

                       ErrorHandlerSrvc.checkData(resp.data);

                        if(resp.data==""){
                            self.noResultMsg = true;
                            self.showTable = false;
                        }else{
                            self.noResultMsg = false;
                            self.showTable = true;
                        }

                    },
                    function (err) {
                        
                        console.log(err)
                        debug = err;

                        self.showTable = false;
                        self.noResultMsg = false;
                        self.errMsg.error = true;
                        self.errMsg.msg = resp.data;
                        self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                    }
            )
        }else{
            self.noResultMsg = false;
            self.showTable = false;
            
        }
    }
    

}

