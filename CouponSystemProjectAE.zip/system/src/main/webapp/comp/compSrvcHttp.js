(function()
{

    var module = angular.module("compApp");

    module.service("compServiceHTTP", compServiceHTTPCtor);


        function compServiceHTTPCtor( $http )
            {

                    this.getCoupons = function()
                    {
                            var promise = $http.get('http://localhost:8080/system/webapi/company/coupon')
                            return promise
                    }
               
                   
               
                    this.getCoupon = function(coupIdG)
                    {
                        var promise = $http.get('http://localhost:8080/system/webapi/company/coupon/'+ coupIdG)
                        return promise
                    }
                    
                        this.getCoupByType = function(coupType)
                        {
                            var promise =  $http.get('http://localhost:8080/system/webapi/company/getByType/'+ coupType)
                            return promise
                        }
                        this.getCoupByLimit = function(coupPriceLimit)
                        {
                            var promise = $http.get('http://localhost:8080/system/webapi/company/getByLimit/'+ coupPriceLimit)
                            return promise
                        }
                        this.getCoupUntilEndDate = function(limitDate){
                         
                            var promise = $http.get('http://localhost:8080/system/webapi/company/getUntilEndDate/'+ limitDate)
                            return promise
                        }
                        
                        this.veiwCompDetails = function(){
                            var promise = $http.get('http://localhost:8080/system/webapi/company/details')
                            return promise
                        }
                        this.createCoupon = function(coup){
                         
                            var promise = $http.post('http://localhost:8080/system/webapi/company/coupon', coup)
                            return promise
                        }
                      
                        this.updateCoupon = function(coupUpdate){
                           
                            var promise = $http.put('http://localhost:8080/system/webapi/company/coupon', coupUpdate)
                            return promise
                        }
                        
                        
                        this.deleteCoupon = function(id){
                            var promise = $http.delete('http://localhost:8080/system/webapi/company/coupon/' + id)
                            return promise
                        }

                        
            }


    })();
