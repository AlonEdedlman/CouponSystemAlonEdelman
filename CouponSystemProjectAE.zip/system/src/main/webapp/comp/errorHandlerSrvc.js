(function()
{

    var module = angular.module("compApp");

    module.service("ErrorHandlerSrvc", ErrorHandlerSrvcCtor);

    

        function ErrorHandlerSrvcCtor()
            {

              this.result = {"error": false, "data":""};
              var self = this;
              this.emptyChek = function(value){

                if(value==""){
                   return false;
                }
                return true;
              }

              this.nullCheck = function(value){
                  if(value == null || value == undefined){
                      return false;
                  }
                  return true;
              } 

              this.checkPrice = function(priceValue){
                  var result = {"error": false, "msg":""};
                  
                      if(this.nullCheck(priceValue)){
                          if(priceValue >= 0 && priceValue <= 10000){
                              return result;

                          }
                          result.error = true;
                          result.msg = "The price should be between 0 to 10000";
                          return result;
                          }
                          result.error = true;
                          result.msg = "Please enter price!";
                          return result;
                      
                     
                  }

              
                  this.checkData = function(data){
                    if(data == "noFacade"){
                        window.location.href = "../login/login.html";
                    }
                  }

                  

                  this.getErrDetails = function(err){
                    var result = {"error": false, "msg":""};
                    if(err.status==500){
                        result.error = true;
                        result.msg = err.data;
                    }
                    if(err.status==404){
                        result.error = true;
                        result.msg = "there was an error!";
                    }
                    return result;
                  }
              }
    })();
