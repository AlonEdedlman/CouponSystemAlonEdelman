var module = angular.module("custApp")
module.controller("GetPCoupByTypeCtrl", GetPCoupByTypeCtrlCtor)



function GetPCoupByTypeCtrlCtor(custServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.noResultMsg = false;
    
    this.showTable = false;
    this.couponsByType = [];
    var self = this;



    this.orderB = "";
	this.goUp = false;
    
	this.setOrder = function (field) {
		this.goUp = (this.orderB != field) ? false : !this.goUp;
		this.orderB = field;
		console.log(this.orderB)
		this.getAllPurchasedCouponsByType()

	}
   

        this.getAllPurchasedCouponsByType = function(){
            var promise = custServiceHTTP.getAllPurchasedCouponsByType(this.coupType)
            promise.then(
                
                        function (resp) {
                            console.log(resp.data);
                            debug = resp;
                            self.errDetails = {"error": false, "msg":""};
                            ErrorHandlerSrvc.checkData(resp.data);
                            self.couponsByType = resp.data;

                            if(resp.data==""){
                                self.noResultMsg = true;
                                self.showTable=false;
                            }else{
                                self.showTable=true;
                                self.noResultMsg = false;
                            }
                        },
                        function (err) {
                
                            console.log(err)
                            debug = err;
                            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);

                        self.noResultMsg = true;
                        self.showTable = false;
                        }
                    )
                     }
}